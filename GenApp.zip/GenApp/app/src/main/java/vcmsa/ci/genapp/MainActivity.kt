package vcmsa.ci.genapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import kotlin.system.exitProcess

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // Initialize UI components
        val tvHeader = findViewById<TextView>(R.id.tvHeader)
        val etUserInput = findViewById<EditText>(R.id.etUserInput)
        val btnCheck = findViewById<Button>(R.id.btnCheck)
        val tvLabel = findViewById<TextView>(R.id.tvLabel)
        val tvResult = findViewById<TextView>(R.id.tvResult)
        val btnClear = findViewById<Button>(R.id.btnClear)
        val btnExit = findViewById<Button>(R.id.btnExit)

        // Button click for checking the generation
        btnCheck.setOnClickListener {
            val yearText = etUserInput.text.toString().trim()

            if (yearText.isEmpty()) {
                tvResult.text = "Please enter a year."
                return@setOnClickListener
            }

            val year = yearText.toIntOrNull()
            if (year == null || year !in 1901..2024) {
                tvResult.text = "The year you have entered is incorrect"
                return@setOnClickListener
            }

            val generation = generateGenerationYear(year)
            tvResult.text = "You belong to: $generation"
        }

        // Clear button
        btnClear.setOnClickListener {
            etUserInput.text.clear()
            tvResult.text = ""
        }

        // Exit button
        btnExit.setOnClickListener {
            moveTaskToBack(true)
            android.os.Process.killProcess(android.os.Process.myPid())
            exitProcess(0)
        }
    }

    // Function to determine the generation based on birth year
    private fun generateGenerationYear(year: Int): String {
        return when (year) {
            in 1901..1927 -> "The Greatest Generation"
            in 1928..1945 -> "The Silent Generation"
            in 1946..1964 -> "Baby Boom Generation"
            in 1965..1980 -> "Generation X"
            in 1981..1996 -> "Millennial Generation"
            in 1997..2010 -> "Generation Z"
            in 2011..2024 -> "Generation Alpha"
            else -> "Unknown"
        }
    }
}